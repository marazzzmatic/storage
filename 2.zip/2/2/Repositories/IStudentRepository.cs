// Repositories/IStudentRepository.cs
using StudentApi.Dtos;
using StudentApi.Models;

namespace StudentApi.Repositories;

public interface IStudentRepository
{
    Task<(List<Student> Items, int TotalCount)> GetAllAsync(int pageNumber, int pageSize);
    Task<Student?> GetByIdAsync(int id);
    Task<Student> AddAsync(Student student);
    Task<bool> UpdateAsync(int id, StudentUpdateDto dto);
    Task<bool> DeleteAsync(int id);
    Task<Grade?> AddGradeAsync(int studentId, Grade grade);
}