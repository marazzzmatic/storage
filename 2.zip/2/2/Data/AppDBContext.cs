// Data/AppDbContext.cs
using Microsoft.EntityFrameworkCore;
using StudentApi.Models;

namespace StudentApi.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Student> Students => Set<Student>();
    public DbSet<Grade> Grades => Set<Grade>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Student>(entity =>
        {
            entity.ToTable("students");
            entity.HasKey(s => s.Id);
        });

        modelBuilder.Entity<Grade>(entity =>
        {
            entity.ToTable("grades");
            entity.HasKey(g => g.Id);
            entity.HasOne(g => g.Student)
                  .WithMany(s => s.Grades)
                  .HasForeignKey(g => g.StudentId)
                  .OnDelete(DeleteBehavior.Cascade); // Удаление оценок при удалении студента
        });
    }
}