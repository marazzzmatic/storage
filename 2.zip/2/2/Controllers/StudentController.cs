// Controllers/StudentsController.cs
using Microsoft.AspNetCore.Mvc;
using StudentApi.Dtos;
using StudentApi.Models;
using StudentApi.Repositories;

namespace StudentApi.Controllers;

[ApiController]
[Route("api/students")]
public class StudentsController : ControllerBase
{
    private readonly IStudentRepository _repository;

    public StudentsController(IStudentRepository repository)
    {
        _repository = repository;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
    {
        if (pageNumber < 1) pageNumber = 1;
        if (pageSize < 1 || pageSize > 100) pageSize = 10;

        var (items, totalCount) = await _repository.GetAllAsync(pageNumber, pageSize);

        var result = items.Select(s => new StudentResponseDto
        {
            Id = s.Id,
            FullName = s.FullName,
            Group = s.Group,
            Email = s.Email,
            Grades = s.Grades.Select(g => new GradeDto { Id = g.Id, Subject = g.Subject, Value = g.Value }).ToList()
        }).ToList();

        return Ok(new
        {
            PageNumber = pageNumber,
            PageSize = pageSize,
            TotalCount = totalCount,
            TotalPages = (int)Math.Ceiling((double)totalCount / pageSize),
            Items = result
        });
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        var student = await _repository.GetByIdAsync(id);
        if (student == null) return NotFound(new { Message = $"Студент с ID {id} не найден" });

        return Ok(new StudentResponseDto
        {
            Id = student.Id,
            FullName = student.FullName,
            Group = student.Group,
            Email = student.Email,
            Grades = student.Grades.Select(g => new GradeDto { Id = g.Id, Subject = g.Subject, Value = g.Value }).ToList()
        });
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] StudentCreateDto dto)
    {
        var student = new Student
        {
            FullName = dto.FullName,
            Group = dto.Group,
            Email = dto.Email
        };

        var created = await _repository.AddAsync(student);

        return CreatedAtAction(nameof(GetById), new { id = created.Id }, new
        {
            Id = created.Id,
            FullName = created.FullName,
            Group = created.Group,
            Email = created.Email
        });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] StudentUpdateDto dto)
    {
        var updated = await _repository.UpdateAsync(id, dto);
        if (!updated) return NotFound(new { Message = $"Студент с ID {id} не найден" });

        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted = await _repository.DeleteAsync(id);
        if (!deleted) return NotFound(new { Message = $"Студент с ID {id} не найден" });

        return NoContent();
    }

    [HttpPost("{id:int}/grades")]
    public async Task<IActionResult> AddGrade(int id, [FromBody] GradeCreateDto dto)
    {
        var grade = new Grade
        {
            Subject = dto.Subject,
            Value = dto.Value
        };

        var created = await _repository.AddGradeAsync(id, grade);
        if (created == null) return NotFound(new { Message = $"Студент с ID {id} не найден" });

        return Ok(new
        {
            Id = created.Id,
            StudentId = created.StudentId,
            Subject = created.Subject,
            Value = created.Value
        });
    }
}