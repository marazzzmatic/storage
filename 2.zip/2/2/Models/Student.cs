// Models/Student.cs
using System.Collections.Generic;

namespace StudentApi.Models;

public class Student
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Group { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public ICollection<Grade> Grades { get; set; } = new List<Grade>();
}

