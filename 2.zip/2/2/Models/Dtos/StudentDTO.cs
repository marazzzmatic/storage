// Dtos/StudentDtos.cs
using System.Collections.Generic;

namespace StudentApi.Dtos;

public class GradeCreateDto
{
    public string Subject { get; set; } = string.Empty;
    public int Value { get; set; }
}

public class StudentCreateDto
{
    public string FullName { get; set; } = string.Empty;
    public string Group { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
}

public class StudentUpdateDto
{
    public string FullName { get; set; } = string.Empty;
    public string Group { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
}

public class GradeDto
{
    public int Id { get; set; }
    public string Subject { get; set; } = string.Empty;
    public int Value { get; set; }
}

public class StudentResponseDto
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Group { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public List<GradeDto> Grades { get; set; } = new();
}