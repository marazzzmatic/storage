// Models/Grade.cs
namespace StudentApi.Models;

public class Grade
{
    public int Id { get; set; }
    public string Subject { get; set; } = string.Empty;
    public int Value { get; set; }
    public int StudentId { get; set; }
    public Student Student { get; set; } = null!;
}