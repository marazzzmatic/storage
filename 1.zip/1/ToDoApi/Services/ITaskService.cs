using ToDoApi.DTOs;

namespace ToDoApi.Services;

public interface ITaskService
{
    Task<PagedResult<TaskDto>> GetAllAsync(int page, int pageSize, CancellationToken ct);
    Task<TaskDto?> GetByIdAsync(int id, CancellationToken ct);
    Task<TaskDto> CreateAsync(CreateTaskDto dto, CancellationToken ct);
    Task<TaskDto?> UpdateAsync(int id, UpdateTaskDto dto, CancellationToken ct);
    Task<bool> DeleteAsync(int id, CancellationToken ct);
}