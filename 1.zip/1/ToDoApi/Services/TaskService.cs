using Microsoft.EntityFrameworkCore;
using ToDoApi.DTOs;
using ToDoApi.Data;
using ToDoApi.Models;

namespace ToDoApi.Services;

public class TaskService : ITaskService
{
    private readonly ToDoApiContext _context;

    public TaskService(ToDoApiContext context)
    {
        _context = context;
    }

    public async Task<PagedResult<TaskDto>> GetAllAsync(int page, int pageSize, CancellationToken ct)
    {
        var totalCount = await _context.Tasks.CountAsync(ct);

        var items = await _context.Tasks
            .AsNoTracking()
            .OrderByDescending(t => t.Priority) // Например, сортируем по приоритету
            .ThenByDescending(t => t.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(t => new TaskDto(
                t.Id,
                t.Title,
                t.Description,
                t.Priority,
                t.Done,        // Используем Done
                t.CreatedAt))  // Убрали UpdatedAt
            .ToListAsync(ct);

        return new PagedResult<TaskDto>(items, page, pageSize, totalCount);
    }

    public async Task<TaskDto?> GetByIdAsync(int id, CancellationToken ct)
    {
        var task = await _context.Tasks
            .AsNoTracking()
            .FirstOrDefaultAsync(t => t.Id == id, ct);

        if (task is null) return null;

        return new TaskDto(
            task.Id,
            task.Title,
            task.Description,
            task.Priority,
            task.Done,
            task.CreatedAt);
    }

    public async Task<TaskDto> CreateAsync(CreateTaskDto dto, CancellationToken ct)
    {
        var task = new TaskItem
        {
            Title = dto.Title,
            Description = dto.Description,
            Priority = dto.Priority,
            Done = false, 
            // CreatedAt инициализируется автоматически в вашей модели
        };

        _context.Tasks.Add(task);
        await _context.SaveChangesAsync(ct);

        return new TaskDto(
            task.Id,
            task.Title,
            task.Description,
            task.Priority,
            task.Done,
            task.CreatedAt);
    }

    public async Task<TaskDto?> UpdateAsync(int id, UpdateTaskDto dto, CancellationToken ct)
    {
        var task = await _context.Tasks.FirstOrDefaultAsync(t => t.Id == id, ct);
        if (task is null) return null;

        task.Title = dto.Title;
        task.Description = dto.Description;
        task.Priority = dto.Priority;
        task.Done = dto.Done;
        // UpdatedAt убрали, так как в модели его нет

        await _context.SaveChangesAsync(ct);

        return new TaskDto(
            task.Id,
            task.Title,
            task.Description,
            task.Priority,
            task.Done,
            task.CreatedAt);
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken ct)
    {
        var task = await _context.Tasks.FirstOrDefaultAsync(t => t.Id == id, ct);
        if (task is null) return false;

        _context.Tasks.Remove(task);
        await _context.SaveChangesAsync(ct);
        return true;
    }
}