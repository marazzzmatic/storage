namespace ToDoApi.DTOs;

public record TaskDto(
    int Id,
    string Title,
    string Description,
    string Priority,
    bool Done,
    DateTime CreatedAt);

public record CreateTaskDto(
    string Title, 
    string Description, 
    string Priority);

public record UpdateTaskDto(
    string Title, 
    string Description, 
    string Priority, 
    bool Done);

public record PagedResult<T>(IReadOnlyList<T> Items, int Page, int PageSize, int TotalCount)
{
    public int TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);
}