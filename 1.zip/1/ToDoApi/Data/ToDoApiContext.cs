using ToDoApi.Models;
using Microsoft.EntityFrameworkCore;

namespace ToDoApi.Data;
public class ToDoApiContext : DbContext
{
    public ToDoApiContext(DbContextOptions<ToDoApiContext> options)
        : base(options) { }

    public DbSet<TaskItem> Tasks => Set<TaskItem>();
}